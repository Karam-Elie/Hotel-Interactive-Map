import React, { useRef, useState } from "react";

/**
 * Anassa – Interactive Map (Final Polished Version)
 * - Full image display (no cropping)
 * - Clean arrows (no white bubbles, no borders)
 * - Room info above image
 */

const MAP_URL = "https://i.ibb.co/P3YJq7y/Anassa-Map.jpg";

const ROOM_DATA = [
  {
    id: "10",
    roomNumber: "10",
    type: "Andromeda Residence with Pool",
    coords: { x: 75.6, y: 15 },
    images: ["https://i.ibb.co/FL5zZBmH/Andromeda.webp"],
    info:
      "With its opulent interiors, captivating sea views and private infinity pool, this alluring three-bedroom residence is ideal for families.\n\n" +
      "Size: 225 m²\nUp to 9 people\nThree en-suite bedrooms, each with balcony\n" +
      "Infinity pool (4 x 9 m, heated on request)\nLarge sea-view sun terrace (65 m²)\nBath and Shower\n\n" +
      "Facilities & Amenities:\nWI-FI (Complimentary)\nIn-room bar\nWelcome bottle of Champagne\n" +
      "Daily fruit selection\nDaily Replenished Water & Chef’s treats\nEspresso Machine\nSatellite TV & DVD Player\n" +
      "Safety Deposit Box\nBathrobe / Slippers\nNightly Turn Down Service",
  },
  {
    id: "88",
    roomNumber: "88",
    type: "Alexandros Residence with Pool",
    coords: { x: 10.2, y: 44.1 },
    images: ["https://i.ibb.co/Z0JSpTB/Alexandros.webp"],
    info:
      "Everything about our ultimate accommodation is majestic: the views, the antiques and art, the grand entrance foyer, and the lush private gardens.\n\n" +
      "Size: 185 m²\nUp to 6 people\nTwo en-suite bedrooms, each with balcony\n" +
      "Infinity pool (4 x 8 m, heated on request)\nLarge sea-view sun terrace (67 m²)\nBath and Shower\n\n" +
      "Facilities & Amenities:\nWi-Fi\nIn-room bar\nWelcome bottle of Champagne\nDaily fruit selection\n" +
      "Daily replenished water & Chef’s treats\nEspresso Machine\nSatellite TV & DVD Player\nSafety Deposit Box\n" +
      "Bathrobe / Slippers\nNightly Turn Down Service",
  },
  {
    id: "81",
    roomNumber: "81",
    type: "Aether Residence",
    coords: { x: 7.9, y: 52.9 },
    images: ["https://i.ibb.co/fGQL2JZk/Aether.webp"],
    info:
      "A three-bedroom villa with vast sun-lit interiors and an extensive outdoor terrace, handcrafted furnishings, king-size day beds and an infinity-edge pool with sea views.\n\n" +
      "Size: 225 m²\nUp to 9 people\nThree en-suite bedrooms, each with balcony\nInfinity pool (4 x 9 m, heated on request)\n" +
      "Large sea-view sun terrace (66 m²)\nBath and Shower\n\n" +
      "Facilities & Amenities:\nWI-FI (Complimentary)\nIn-room bar\nWelcome bottle of Champagne\nDaily fruit selection\n" +
      "Daily Replenished Water & Chef’s treats\nEspresso Machine\nSatellite TV & DVD Player\nSafety Deposit Box\n" +
      "Bathrobe / Slippers\nNightly Turn Down Service",
  },
  {
    id: "66",
    roomNumber: "66",
    type: "Alcyone Residence",
    coords: { x: 30.2, y: 55.6 },
    images: ["https://i.ibb.co/39S1WLjz/Alcyone.webp"],
    info:
      "A tranquil two-bedroom sea view oasis with fresh individual styling. Perfect for enjoying special moments, from breakfast by the pool to a nightcap by the outdoor fire.\n\n" +
      "Size: 178 m²\nUp to 6 people\nTwo en suite bedrooms, each with balcony\nInfinity pool (5 x 9 m, heated on request)\n" +
      "Large sea-view sun terrace (69 m²)\nBath and Shower\n\n" +
      "Facilities & Amenities:\nWI-FI (Complimentary)\nIn-room bar\nWelcome bottle of Champagne\nDaily fruit selection\n" +
      "Daily Replenished Water & Chef’s treats\nEspresso Machine\nSatellite TV & DVD Player\nSafety Deposit Box\n" +
      "Bathrobe / Slippers\nNightly Turn Down Service",
  },
  {
    id: "pool1",
    roomNumber: "Indoor Swimming Pool",
    type: "",
    coords: { x: 28.6, y: 10.5 },
    images: ["https://i.ibb.co/dJtfZgSp/gallery-spa-3-1900x1190.jpg"],
    info: "A serene heated indoor pool with skylight roof, perfect for year-round swimming.",
  },
  {
    id: "view1",
    roomNumber: "",
    type: "",
    coords: { x: 48.1, y: 53.7 },
    images: ["https://i.ibb.co/zhBKpByq/amorosa-terrace.jpg"],
    info: "",
  },
  {
    id: "beach1",
    roomNumber: "",
    type: "",
    coords: { x: 59.4, y: 89.7 },
    images: [
      "https://i.ibb.co/yFJgJ2fC/anassa-beach.jpg",
      "https://i.ibb.co/dswwsJV9/anassa-beach2.jpg",
    ],
    info: "",
  },
];

// Carousel Component
function Carousel({ images }) {
  const [index, setIndex] = useState(0);
  const prev = () => setIndex((i) => (i === 0 ? images.length - 1 : i - 1));
  const next = () => setIndex((i) => (i === images.length - 1 ? 0 : i + 1));

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        overflow: "hidden",
        background: "#000",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <img
        src={images[index]}
        alt=""
        style={{
          width: "100%",
          height: "auto",
          maxHeight: "75vh",
          objectFit: "contain",
          borderRadius: 0,
          transition: "opacity 0.3s ease",
        }}
      />

      {images.length > 1 && (
        <>
          <button
            onClick={prev}
            style={{
              position: "absolute",
              left: 20,
              top: "50%",
              transform: "translateY(-50%)",
              background: "transparent",
              border: "none",
              outline: "none",
              boxShadow: "none",
              cursor: "pointer",
              fontSize: 42,
              fontWeight: 500,
              color: "rgba(255,255,255,0.8)",
              transition: "color 0.2s",
            }}
            onMouseEnter={(e) => (e.target.style.color = "#fff")}
            onMouseLeave={(e) =>
              (e.target.style.color = "rgba(255,255,255,0.8)")
            }
          >
            ‹
          </button>

          <button
            onClick={next}
            style={{
              position: "absolute",
              right: 20,
              top: "50%",
              transform: "translateY(-50%)",
              background: "transparent",
              border: "none",
              outline: "none",
              boxShadow: "none",
              cursor: "pointer",
              fontSize: 42,
              fontWeight: 500,
              color: "rgba(255,255,255,0.8)",
              transition: "color 0.2s",
            }}
            onMouseEnter={(e) => (e.target.style.color = "#fff")}
            onMouseLeave={(e) =>
              (e.target.style.color = "rgba(255,255,255,0.8)")
            }
          >
            ›
          </button>
        </>
      )}
    </div>
  );
}

export default function App() {
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [query, setQuery] = useState("");
  const imgRef = useRef(null);

  const handleSearch = (e) => {
    if (e.key === "Enter") {
      const q = query.trim().toLowerCase();
      if (!q) return;
      const found = ROOM_DATA.find((r) =>
        [r.roomNumber, r.type, r.info || ""].join(" ").toLowerCase().includes(q)
      );
      if (found) setSelectedRoom(found);
    }
  };

  return (
    <div style={{ fontFamily: "Aptos Display, system-ui, Arial, sans-serif" }}>
      {/* Header */}
      <div
        style={{
          position: "sticky",
          top: 0,
          zIndex: 10,
          padding: "10px 16px",
          borderBottom: "1px solid #ddd",
          background: "#fff",
          display: "flex",
          alignItems: "center",
          gap: 8,
        }}
      >
        <strong>Anassa – Interactive Map</strong>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleSearch}
          placeholder="Search room number or type…"
          style={{
            marginLeft: "auto",
            padding: "8px",
            border: "1px solid #ccc",
            borderRadius: 8,
            minWidth: 260,
          }}
        />
      </div>

      {/* Map */}
      <div style={{ position: "relative", width: "100%", background: "#000" }}>
        <img
          ref={imgRef}
          src={MAP_URL}
          alt="Anassa Map"
          style={{ width: "100%", height: "auto", display: "block" }}
        />

        {ROOM_DATA.map((room) => (
          <div
            key={room.id}
            onClick={(e) => {
              e.stopPropagation();
              setSelectedRoom(room);
            }}
            style={{
              position: "absolute",
              left: `${room.coords.x}%`,
              top: `${room.coords.y}%`,
              transform: "translate(-50%, -50%)",
              width: "1.5%",
              height: "2.5%",
              cursor: "pointer",
              borderRadius: "50%",
              background: "transparent",
            }}
          />
        ))}
      </div>

      {/* Popup */}
      {selectedRoom && (
        <div
          onClick={() => setSelectedRoom(null)}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 100,
            padding: 16,
          }}
        >
          {selectedRoom.type || selectedRoom.roomNumber ? (
            // ROOM POPUP
            <div
              onClick={(e) => e.stopPropagation()}
              style={{
                background: "#fff",
                borderRadius: 12,
                width: "680px",
                height: "85vh",
                display: "flex",
                flexDirection: "column",
                overflow: "hidden",
                position: "relative",
                boxShadow: "0 4px 30px rgba(0,0,0,0.3)",
              }}
            >
              <button
                onClick={() => setSelectedRoom(null)}
                style={{
                  position: "absolute",
                  top: 10,
                  right: 14,
                  border: "none",
                  background: "transparent",
                  fontSize: 22,
                  cursor: "pointer",
                  color: "#666",
                  zIndex: 10,
                }}
              >
                ×
              </button>

              <div style={{ padding: "18px 20px 10px", background: "#fff" }}>
                {selectedRoom.roomNumber && (
                  <div
                    style={{
                      fontSize: "1.6rem",
                      fontWeight: 700,
                      color: "#1a1a1a",
                    }}
                  >
                    Room {selectedRoom.roomNumber}
                  </div>
                )}
                {selectedRoom.type && (
                  <div
                    style={{
                      marginTop: 2,
                      fontSize: "1.2rem",
                      fontWeight: 650,
                      color: "#2a2a2a",
                    }}
                  >
                    {selectedRoom.type}
                  </div>
                )}
              </div>

              {selectedRoom.images?.length > 0 && (
                <Carousel images={selectedRoom.images} />
              )}

              {selectedRoom.info && (
                <div
                  style={{
                    overflowY: "auto",
                    padding: "18px 22px 24px",
                    flex: 1,
                  }}
                >
                  <p
                    style={{
                      fontSize: 14.5,
                      color: "#444",
                      whiteSpace: "pre-wrap",
                      marginTop: 0,
                      lineHeight: 1.55,
                    }}
                  >
                    {selectedRoom.info}
                  </p>
                </div>
              )}
            </div>
          ) : (
            // IMAGE-ONLY HOTSPOT POPUP
            <div
              onClick={(e) => e.stopPropagation()}
              style={{
                borderRadius: 12,
                width: "80vw",
                maxWidth: "1000px",
                maxHeight: "90vh",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                overflow: "hidden",
                position: "relative",
                background: "#000",
                boxShadow: "0 4px 30px rgba(0,0,0,0.3)",
              }}
            >
              <button
                onClick={() => setSelectedRoom(null)}
                style={{
                  position: "absolute",
                  top: 10,
                  right: 14,
                  border: "none",
                  background: "transparent",
                  fontSize: 26,
                  cursor: "pointer",
                  color: "#fff",
                  zIndex: 10,
                }}
              >
                ×
              </button>
              <Carousel images={selectedRoom.images} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
